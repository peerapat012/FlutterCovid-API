import 'package:covidnew/utills/color_utills.dart';
import 'package:flutter/material.dart';

class Info_history extends StatefulWidget {
  const Info_history({Key? key}) : super(key: key);

  @override
  State<Info_history> createState() => _Info_historyState();
}

class _Info_historyState extends State<Info_history> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text("ข้อมูลการจองวัคซีน"),backgroundColor: Color(0xff121421),),
      body: ListView(
        children: <Widget>[
          Container(
            child: Padding(
              padding: const EdgeInsets.all(10.0),
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                crossAxisAlignment: CrossAxisAlignment.center,
                children: <Widget>[
                  SizedBox(
                    height: 15,
                  ),
                  Text("Test",style: TextStyle(fontSize: 18),),
                  SizedBox(
                    height: 10,
                  ),
                  Text("Test",style: TextStyle(fontSize: 18),),
                  SizedBox(
                    height: 10,
                  ),
                  Text("Test",style: TextStyle(fontSize: 18),),
                  SizedBox(
                    height: 10,
                  ),
                  Text("Test",style: TextStyle(fontSize: 18),),
                  SizedBox(
                    height: 10,
                  ),
                  Text("Test",style: TextStyle(fontSize: 18),),
                  SizedBox(
                    height: 10,
                  ),
                  Text("Test",style: TextStyle(fontSize: 18),),
                  SizedBox(
                    height: 10,
                  ),
                  Text("Test",style: TextStyle(fontSize: 18),),
                  SizedBox(
                    height: 10,
                  ),
                  Text("Test",style: TextStyle(fontSize: 18),),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}
