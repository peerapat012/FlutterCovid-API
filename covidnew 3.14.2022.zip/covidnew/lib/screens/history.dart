import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:covidnew/model/model.dart';
import 'package:covidnew/screens/page_account.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:fluttertoast/fluttertoast.dart';

class OrderHistoryPage extends StatefulWidget {
  const OrderHistoryPage({Key? key}) : super(key: key);

  @override
  State<OrderHistoryPage> createState() => _OrderHistoryPageState();
}

class _OrderHistoryPageState extends State<OrderHistoryPage> {
  User? user = FirebaseAuth.instance.currentUser;
  VaccineModel vaccineModel = VaccineModel();
  CollectionReference vacc = FirebaseFirestore.instance.collection('vacOder');
  final _auth = FirebaseAuth.instance;

  @override
  void initState() {
    super.initState();
    FirebaseFirestore.instance
        .collection("vacOder")
        .doc(user!.uid)
        .get()
        .then((value) {
      this.vaccineModel = VaccineModel.fromMap(value.data());
      setState(() {});
    });
  }

  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text("ประวัติการจองวัคซีน"),backgroundColor: Color(0xff121421),),
      backgroundColor: Color(0xff121421),
      body: ListView(
        children: <Widget>[
          Padding(
            padding: const EdgeInsets.all(8.0),
            child: Card(
              child: Column(
                children: <Widget>[
                  Padding(
                    padding: const EdgeInsets.all(8.0),
                    child: Text("ประวัติการจองวัคซีน"),
                  ),
                  Divider(),
                  Padding(
                    padding: const EdgeInsets.all(8.0),
                    child: Column(
                      children: <Widget>[
                        Card(
                          child: Container(
                            child: ListTile(
                              onTap: () {
                                Navigator.of(context).pop();
                                Navigator.of(context).pushNamed('/history');
                              },
                              leading: Icon(Icons.account_circle),
                              title: Text("ชื่อ"),
                              subtitle: Text("ข้อมูลการจอง"),
                              trailing: Icon(Icons.keyboard_arrow_right),
                            ),
                          ),
                        ),
                      ],
                    ),
                  )
                ],
              ),
            ),
          )
        ],
      ),
    );
  }
}
